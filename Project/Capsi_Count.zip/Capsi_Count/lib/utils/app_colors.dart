// lib/utils/app_colors.dart

import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryColor = Color(0xFF6A1B9A); // Deep Purple
  static const Color secondaryColor = Color(0xFFBA68C8); // Light Purple
  static const Color textColor = Colors.white;
  static const Color backgroundColor = Colors.white;
}
