import 'package:flutter/material.dart';

class RoomCard extends StatelessWidget {
  final String title;
  final int currentPersons;
  final int maxRange;
  final int remainingSpace;
  final double temperature;
  final double humidity;

  const RoomCard({
    Key? key,
    required this.title,
    required this.currentPersons,
    required this.maxRange,
    required this.remainingSpace,
    required this.temperature,
    required this.humidity,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double screenHeight = MediaQuery.of(context).size.height;

    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 6,
      shadowColor: Colors.black54,
      child: Container(
        height: screenHeight * 0.36,
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            colors: [Colors.deepPurple.shade700, Colors.deepPurple.shade400],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _infoItem(Icons.people, 'Current', currentPersons.toString()),
                _infoItem(Icons.speed, 'Max', maxRange.toString()),
                _infoItem(
                  Icons.space_bar,
                  'Remaining',
                  remainingSpace.toString(),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _infoItem(
                  Icons.thermostat,
                  'Temp',
                  '${temperature.toStringAsFixed(1)}°C',
                ),
                _infoItem(
                  Icons.water_drop,
                  'Humidity',
                  '${humidity.toStringAsFixed(1)}%',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoItem(IconData icon, String label, String value) {
    return Expanded(
      child: Column(
        children: [
          Icon(icon, color: Colors.white70, size: 20),
          const SizedBox(height: 2),
          Text(
            label,
            style: const TextStyle(color: Colors.white70, fontSize: 12),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}
