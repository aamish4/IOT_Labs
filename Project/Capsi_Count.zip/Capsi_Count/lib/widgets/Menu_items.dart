import 'package:flutter/material.dart';

class MenuItem extends StatelessWidget {
  final String iconPath;
  final String text;
  final int index;
  final void Function(int) onTap;

  const MenuItem({
    super.key,
    required this.iconPath,
    required this.text,
    required this.index,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    return Padding(
      padding: EdgeInsets.symmetric(vertical: screenWidth * 0.02),
      child: Material(
        borderRadius: BorderRadius.circular(12),
        color: Colors.white,
        elevation: 2,
        shadowColor: Colors.black12,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => onTap(index),
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 16.0,
              vertical: 14.0,
            ),
            child: Row(
              children: [
                Image.asset(
                  iconPath,
                  width: 26,
                  height: 26,
                  color: const Color(0xFF5F3692),
                ),
                const SizedBox(width: 20),
                Text(
                  text,
                  style: const TextStyle(
                    fontSize: 18,
                    fontFamily: 'SF Pro Display',
                    fontWeight: FontWeight.w500,
                    color: Color(0xFF5F3692),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
