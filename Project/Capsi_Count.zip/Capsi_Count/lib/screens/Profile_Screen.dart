import 'dart:io';

import 'package:flutter/material.dart';
import 'package:fresh_check/methods/General_Methods.dart';
import 'package:fresh_check/screens/Edit_ProfileScreen.dart';
import 'package:fresh_check/widgets/Menu_items.dart';

class ProfileScreen extends StatefulWidget {
  final String userName;
  final String userEmail;
  final String? profileImageUrl;

  const ProfileScreen({
    Key? key,
    required this.userName,
    required this.userEmail,
    this.profileImageUrl,
  }) : super(key: key);

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _isDarkMode = false;
  bool _isEditingProfile = false;

  final GeneralMethods abc = GeneralMethods();

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFF2E9FF), Color(0xFFE6D6FA)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: EdgeInsets.all(screenWidth * 0.04),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 20),

                // Profile Section
                _buildProfileCard(),

                const SizedBox(height: 20),

                // Menu Options
                Expanded(
                  child: ListView.builder(
                    itemCount: 7,
                    itemBuilder: (context, index) {
                      return MenuItem(
                        iconPath: abc.getIconPath(index + 1),
                        text: abc.getMenuItemText(index + 1),
                        index: index + 1,
                        onTap: (int index) => abc.MenuItemIndex(index, context),
                      );
                    },
                  ),
                ),

                const SizedBox(height: 20),

                // Dark Mode Toggle
                _buildDarkModeToggle(),
              ],
            ),
          ),
        ),
      ),

      // Profile Editing Popup
      bottomSheet: _isEditingProfile
          ? Center(
              child: ProfileCard(
                screenWidth: screenWidth,
                onClose: () => setState(() => _isEditingProfile = false),
                onProfileImageTap: abc.editProfileImageTapped,
                obj: abc,
              ),
            )
          : null,
    );
  }

  Widget _buildProfileCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          // Display profile image if available:
          widget.profileImageUrl != null
              ? CircleAvatar(
                  radius: 42,
                  backgroundImage: widget.profileImageUrl!.startsWith('http')
                      ? NetworkImage(widget.profileImageUrl!)
                      : FileImage(File(widget.profileImageUrl!))
                            as ImageProvider,
                )
              : const CircleAvatar(
                  radius: 42,
                  backgroundColor: Color(0xFF5F3692),
                  child: Icon(Icons.person, size: 42, color: Colors.white),
                ),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.userName,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF5F3692),
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  widget.userEmail,
                  style: const TextStyle(fontSize: 14, color: Colors.grey),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: () =>
                setState(() => _isEditingProfile = !_isEditingProfile),
            icon: const Icon(Icons.edit, color: Color(0xFF5F3692)),
          ),
        ],
      ),
    );
  }

  Widget _buildDarkModeToggle() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 2)),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            "Dark Mode",
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Color(0xFF5F3692),
            ),
          ),
          Switch(
            value: _isDarkMode,
            activeColor: const Color(0xFF5F3692),
            onChanged: (bool value) {
              setState(() => _isDarkMode = value);
              abc.darkmode(value);
            },
          ),
        ],
      ),
    );
  }
}
