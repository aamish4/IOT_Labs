import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // for input formatters

class AddNewEvent extends StatefulWidget {
  const AddNewEvent({super.key});

  @override
  State<AddNewEvent> createState() => _AddNewEventState();
}

class _AddNewEventState extends State<AddNewEvent> {
  //--------------------------Variables-----------------------------------------

  final _formKey = GlobalKey<FormState>();
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _maxRangeController = TextEditingController();
  final TextEditingController _currentPeopleController = TextEditingController(
    text: '0',
  );
  final TextEditingController _remainingSpaceController = TextEditingController(
    text: '0',
  );
  final TextEditingController _temperatureController = TextEditingController();
  final TextEditingController _humidityController = TextEditingController();
  int remainingSpace = 0;
  final double temperature = 23.5;
  final int humidity = 57;

  @override
  void initState() {
    super.initState();
    _maxRangeController.addListener(_calculateRemainingSpace);
    _currentPeopleController.addListener(_calculateRemainingSpace);
    _temperatureController.text = '$temperature °C';
    _humidityController.text = '$humidity %';
  }

  void _calculateRemainingSpace() {
    final maxRange = int.tryParse(_maxRangeController.text) ?? 0;
    final currentPeople = int.tryParse(_currentPeopleController.text) ?? 0;

    setState(() {
      remainingSpace = (maxRange - currentPeople).clamp(0, maxRange);
      _remainingSpaceController.text = remainingSpace.toString();
    });
  }

  void _saveForm() async {
    if (_formKey.currentState!.validate()) {
      final String title = _titleController.text;
      final int maxRange = int.parse(_maxRangeController.text);
      final int currentPeople = int.parse(_currentPeopleController.text);
      final int remainingSpace = (maxRange - currentPeople).clamp(0, maxRange);

      final newRoom = {
        'maxRange': maxRange,
        'currentPersons': currentPeople,
        'remainingSpace': remainingSpace,
        'temperature': temperature,
        'humidity': humidity,
      };

      // Get the current user's UID
      final String? userId = FirebaseAuth.instance.currentUser?.uid;

      if (userId == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Error: User not logged in')),
        );
        return;
      }

      // Get a reference to the database
      DatabaseReference dbRef = FirebaseDatabase.instance.ref();

      // Save the room data under the user's node with title as key
      await dbRef.child('users').child(userId).child(title).set(newRoom);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Room info saved successfully!')),
      );

      Navigator.pop(context, newRoom);
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _maxRangeController.dispose();
    _currentPeopleController.dispose();
    _remainingSpaceController.dispose();
    _temperatureController.dispose();
    _humidityController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.deepPurple[900],
      appBar: AppBar(
        title: const Text('Add New Event'),
        backgroundColor: Colors.deepPurple[800],
        centerTitle: true,
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(16)),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.07,
            vertical: screenHeight * 0.03,
          ),
          child: Card(
            elevation: 12,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            color: Colors.deepPurple[700],
            shadowColor: Colors.deepPurpleAccent,
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 24.0,
                vertical: 28,
              ),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _buildTextField(
                      controller: _titleController,
                      label: 'Room Title',
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter room title';
                        }
                        if (value.length > 15) {
                          return 'Title cannot exceed 15 characters';
                        }
                        return null;
                      },
                      maxLength: 15,
                      counterText: '',
                    ),
                    SizedBox(height: 20),
                    _buildTextField(
                      controller: _maxRangeController,
                      label: 'Max Range (Capacity)',
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(2),
                      ],
                      validator: (value) {
                        if (value == null || value.isEmpty)
                          return 'Enter max range';
                        final parsed = int.tryParse(value);
                        if (parsed == null) return 'Enter a valid number';
                        if (parsed <= 0)
                          return 'Max range must be greater than 0';
                        return null;
                      },
                    ),
                    SizedBox(height: 20),
                    _buildTextField(
                      controller: _currentPeopleController,
                      label: 'Current People',
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(2),
                      ],
                      validator: (value) {
                        if (value == null || value.isEmpty)
                          return 'Enter current people';
                        final parsed = int.tryParse(value);
                        if (parsed == null) return 'Enter a valid number';
                        final maxRange =
                            int.tryParse(_maxRangeController.text) ?? 0;
                        if (parsed > maxRange)
                          return 'Current people cannot exceed max range';
                        if (parsed < 0) return 'Value cannot be negative';
                        return null;
                      },
                    ),
                    SizedBox(height: 20),
                    _buildTextField(
                      controller: _remainingSpaceController,
                      label: 'Remaining Space',
                      readOnly: true,
                      backgroundColor: Colors.deepPurple[400],
                      labelColor: Colors.white70,
                      textColor: Colors.white,
                    ),
                    SizedBox(height: 20),
                    // New read-only Temperature field
                    _buildTextField(
                      controller: _temperatureController,
                      label: 'Temperature',
                      readOnly: true,
                      backgroundColor: Colors.deepPurple[400],
                      labelColor: Colors.white70,
                      textColor: Colors.white,
                    ),
                    SizedBox(height: 20),
                    // New read-only Humidity field
                    _buildTextField(
                      controller: _humidityController,
                      label: 'Humidity',
                      readOnly: true,
                      backgroundColor: Colors.deepPurple[400],
                      labelColor: Colors.white70,
                      textColor: Colors.white,
                    ),
                    SizedBox(height: 36),
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton.icon(
                        onPressed: _saveForm,
                        icon: const Icon(Icons.check, size: 24),
                        label: const Text(
                          'Save',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.greenAccent[700],
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                          elevation: 6,
                          shadowColor: Colors.greenAccent,
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
    bool readOnly = false,
    Color? backgroundColor,
    Color? labelColor,
    Color? textColor,
    int? maxLength,
    String? counterText,
    List<TextInputFormatter>? inputFormatters,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      validator: validator,
      readOnly: readOnly,
      inputFormatters: inputFormatters,
      maxLength: maxLength,
      style: TextStyle(
        color: textColor ?? Colors.white,
        fontSize: 16,
        fontWeight: FontWeight.w500,
      ),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(
          color: labelColor ?? Colors.white70,
          fontWeight: FontWeight.w600,
        ),
        filled: backgroundColor != null,
        fillColor: backgroundColor,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(
          vertical: 16,
          horizontal: 20,
        ),
        counterText: counterText,
      ),
      cursorColor: Colors.greenAccent[400],
    );
  }
}
