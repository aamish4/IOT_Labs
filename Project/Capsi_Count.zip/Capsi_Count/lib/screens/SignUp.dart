import 'dart:io';
import 'package:flutter/material.dart';
import 'package:fresh_check/methods/General_Methods.dart';
import 'package:fresh_check/screens/SpashScreen.dart';
import 'package:image_picker/image_picker.dart';
import 'package:fresh_check/screens/LogIn.dart';
import 'package:fresh_check/utils/app_colors.dart';

class SignUp extends StatefulWidget {
  @override
  SignUpState createState() => SignUpState();
}

class SignUpState extends State<SignUp> {
  //-------------------------------Variables-------------------------------
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();
  final GeneralMethods _generalMethods = GeneralMethods();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  File? _selectedImage;
  String? _imagePath;

  //-------------------------------ImagePicker-------------------------------
  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(
      source: ImageSource.gallery,
    );
    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
        _imagePath = pickedFile.path;
      });
    }
  }

  //-------------------------------Sign Up call-------------------------------

  void _handleSignUp() {
    _generalMethods.handleSignUp(
      context: context,
      nameController: nameController,
      emailController: emailController,
      passwordController: passwordController,
      formKey: _formKey,
      selectedImage: _selectedImage,
      imagePath: _imagePath,
      nextScreen: SplashScreen(), // or MainScreen()
    );
  }

  //---------------------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox.expand(
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [AppColors.primaryColor, AppColors.secondaryColor],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const SizedBox(
                    width: double.infinity,
                    child: Text(
                      "Create Account",
                      style: TextStyle(
                        color: AppColors.textColor,
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),

                  const SizedBox(height: 20),

                  GestureDetector(
                    onTap: _pickImage,
                    child: CircleAvatar(
                      radius: 50,
                      backgroundColor: Colors.white,
                      backgroundImage: _selectedImage != null
                          ? FileImage(_selectedImage!)
                          : null,
                      child: _selectedImage == null
                          ? const Icon(
                              Icons.camera_alt,
                              size: 40,
                              color: AppColors.primaryColor,
                            )
                          : null,
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Tap to upload profile image',
                    style: TextStyle(color: Colors.white),
                  ),
                  const SizedBox(height: 30),

                  Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        _buildLabel("Your Name"),
                        _buildTextField(
                          controller: nameController,
                          icon: Icons.person,
                          hintText: "Name",
                          validator: (value) =>
                              value!.isEmpty ? "Please enter your name" : null,
                        ),
                        const SizedBox(height: 15),

                        _buildLabel("Email"),
                        _buildTextField(
                          controller: emailController,
                          icon: Icons.email,
                          hintText: "Email",
                          keyboardType: TextInputType.emailAddress,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return "Please enter your email";
                            }
                            final emailRegex = RegExp(
                              r"^[a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$",
                            );
                            return emailRegex.hasMatch(value)
                                ? null
                                : "Please enter a valid email";
                          },
                        ),
                        const SizedBox(height: 15),

                        _buildLabel("Password"),
                        _buildTextField(
                          controller: passwordController,
                          icon: Icons.lock,
                          hintText: "Password",
                          obscureText: true,
                          validator: (value) => value!.length < 8
                              ? "Must be at least 8 characters"
                              : null,
                        ),
                        const SizedBox(height: 15),

                        _buildLabel("Confirm Password"),
                        _buildTextField(
                          controller: confirmPasswordController,
                          icon: Icons.lock_outline,
                          hintText: "Confirm Password",
                          obscureText: true,
                          validator: (value) => value != passwordController.text
                              ? "Passwords do not match"
                              : null,
                        ),
                        const SizedBox(height: 30),

                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 15),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            onPressed: _handleSignUp,
                            child: const Text(
                              "Sign Up",
                              style: TextStyle(
                                fontSize: 18,
                                color: AppColors.primaryColor,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(height: 30),

                        const Text(
                          "Already have an account?",
                          style: TextStyle(
                            fontSize: 18,
                            color: AppColors.textColor,
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => LogIn()),
                            );
                          },
                          child: const Text(
                            "Login",
                            style: TextStyle(
                              fontSize: 22,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLabel(String text) {
    return SizedBox(
      width: double.infinity,
      child: Text(
        text,
        style: const TextStyle(color: Colors.white, fontSize: 16),
        textAlign: TextAlign.left,
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required IconData icon,
    required String hintText,
    String? Function(String?)? validator,
    TextInputType keyboardType = TextInputType.text,
    bool obscureText = false,
  }) {
    return Container(
      margin: const EdgeInsets.only(top: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 2)),
        ],
      ),
      child: TextFormField(
        controller: controller,
        validator: validator,
        keyboardType: keyboardType,
        obscureText: obscureText,
        style: const TextStyle(color: Colors.black),
        decoration: InputDecoration(
          contentPadding: const EdgeInsets.symmetric(
            vertical: 15,
            horizontal: 20,
          ),
          prefixIcon: Icon(icon, color: AppColors.primaryColor),
          border: InputBorder.none,
          hintText: hintText,
          hintStyle: TextStyle(color: Colors.grey.shade600),
        ),
      ),
    );
  }
}
