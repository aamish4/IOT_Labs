import 'dart:io';

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:fresh_check/methods/General_Methods.dart';
import 'package:fresh_check/screens/Notifications_Screen.dart';
import 'package:fresh_check/screens/Profile_Screen.dart';
import 'package:fresh_check/screens/home_screen.dart';
import 'package:fresh_check/utils/app_colors.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int selectedIndex = 1;
  String? userName;
  String? userEmail;
  String? profileImageUrl;
  final abc = GeneralMethods();

  List<Widget> get pages => [
    const NotificationsScreen(),
    const HomeScreen(),
    ProfileScreen(
      userName: userName ?? "Loading...",
      userEmail: userEmail ?? "Loading...",
      profileImageUrl: profileImageUrl,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _loadUserData();
    _loadProfileImage();
  }

  Future<void> _loadUserData() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid != null) {
      final snapshot = await FirebaseDatabase.instance.ref("users/$uid").get();

      if (snapshot.exists && snapshot.value is Map) {
        final data = Map<String, dynamic>.from(snapshot.value as Map);

        setState(() {
          userName = data['name'] as String?;
          userEmail = data['email'] as String?;
          profileImageUrl = data['profileImagePath'] as String?;
        });
      }
    }
  }

  Future<void> _loadProfileImage() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid != null) {
      final snapshot = await FirebaseDatabase.instance
          .ref("users/$uid/profileImagePath")
          .get();

      if (snapshot.exists) {
        setState(() {
          profileImageUrl = snapshot.value as String;
        });
      }
    }
  }

  void onItemTapped(int index) {
    setState(() {
      selectedIndex = index;
    });
  }

  Widget _navItem({required int index, required Widget child}) {
    final isSelected = selectedIndex == index;
    final isProfileIcon = index == 2;

    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(30),
          onTap: () => onItemTapped(index),
          splashColor: Colors.transparent,
          highlightColor: Colors.transparent,
          child: Container(
            height: 50,
            decoration: BoxDecoration(
              color: (isSelected && !isProfileIcon)
                  ? AppColors.secondaryColor
                  : Colors.transparent,
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: child,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primaryColor,
      body: pages[selectedIndex],
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.only(bottom: 16, left: 16, right: 16),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: SizedBox(
            height: 90,
            child: BottomAppBar(
              elevation: 0,
              color: Colors.transparent,
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.secondaryColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(30),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 28),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _navItem(
                      index: 0,
                      child: Image.asset(
                        "assets/icon/Icon1.png",
                        height: 36,
                        width: 36,
                        color: selectedIndex == 0
                            ? Colors.white
                            : Colors.white70,
                      ),
                    ),
                    _navItem(
                      index: 1,
                      child: Icon(
                        Icons.home_rounded,
                        size: 36,
                        color: selectedIndex == 1
                            ? Colors.white
                            : Colors.white70,
                      ),
                    ),
                    _navItem(
                      index: 2,
                      child: profileImageUrl != null
                          ? CircleAvatar(
                              radius: 20,
                              backgroundImage:
                                  profileImageUrl!.startsWith('http')
                                  ? NetworkImage(profileImageUrl!)
                                  : FileImage(File(profileImageUrl!))
                                        as ImageProvider,
                            )
                          : CircleAvatar(
                              radius: 18,
                              backgroundColor: Colors.white70,
                              child: Icon(Icons.person, color: Colors.black),
                            ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
