import 'package:flutter/material.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  // Static list of notifications
  final List<Map<String, dynamic>> _notifications = const [
    {
      'title': 'Conference Room',
      'message': '⚠️ "Conference Room" is overcrowded!',
      'remaining': 0,
      'current': 15,
      'max': 12,
      'time': '2 mins ago',
    },
    {
      'title': 'Lounge Area',
      'message': '⚠️ "Lounge Area" is almost full (2 spots left)',
      'remaining': 2,
      'current': 18,
      'max': 20,
      'time': '5 mins ago',
    },
    {
      'title': 'Cafeteria',
      'message': '"Cafeteria" is getting crowded',
      'remaining': 25,
      'current': 30,
      'max': 55,
      'time': '12 mins ago',
    },
    {
      'title': 'Library',
      'message': '⚠️ "Library" is almost full (1 spot left)',
      'remaining': 1,
      'current': 19,
      'max': 20,
      'time': '25 mins ago',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Room Alerts',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.deepPurple,
        elevation: 10,
        shadowColor: Colors.deepPurple.withOpacity(0.5),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
        ),
      ),
      backgroundColor: Colors.grey[50],
      body: _notifications.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.notifications_off,
                    size: 60,
                    color: Colors.deepPurple[200],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No active alerts',
                    style: TextStyle(
                      color: Colors.deepPurple[300],
                      fontSize: 22,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
              itemCount: _notifications.length,
              itemBuilder: (context, index) {
                final alert = _notifications[index];
                final isCritical = alert['remaining'] <= 0;
                final isWarning = alert['remaining'] <= (alert['max'] * 0.1);

                return Container(
                  margin: const EdgeInsets.only(bottom: 20),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.deepPurple.withOpacity(0.1),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Card(
                    elevation: 0,
                    color: isCritical
                        ? Colors.deepPurple[50]
                        : isWarning
                        ? Colors.deepPurple[100]
                        : Colors.deepPurple[50],
                    margin: EdgeInsets.zero,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                      side: BorderSide(
                        color: isCritical
                            ? Colors.deepPurple[300]!
                            : isWarning
                            ? Colors.deepPurple[200]!
                            : Colors.deepPurple[100]!,
                        width: 1.5,
                      ),
                    ),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () {
                        // Add tap effect
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('${alert['title']} details'),
                            backgroundColor: Colors.deepPurple,
                          ),
                        );
                      },
                      splashColor: Colors.deepPurple.withOpacity(0.1),
                      highlightColor: Colors.deepPurple.withOpacity(0.05),
                      child: Padding(
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(6),
                                      decoration: BoxDecoration(
                                        color: isCritical
                                            ? Colors.deepPurple[200]
                                            : Colors.deepPurple[100],
                                        shape: BoxShape.circle,
                                      ),
                                      child: Icon(
                                        isCritical
                                            ? Icons.warning_rounded
                                            : Icons.info_outline_rounded,
                                        color: isCritical
                                            ? Colors.deepPurple[800]
                                            : Colors.deepPurple[600],
                                        size: 20,
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Text(
                                      alert['title'],
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.deepPurple[800],
                                      ),
                                    ),
                                  ],
                                ),
                                Text(
                                  alert['time'],
                                  style: TextStyle(
                                    color: Colors.deepPurple[300],
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Text(
                              alert['message'],
                              style: TextStyle(
                                fontSize: 15,
                                color: isCritical
                                    ? Colors.deepPurple[900]
                                    : Colors.deepPurple[700],
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            const SizedBox(height: 16),
                            LinearProgressIndicator(
                              value: alert['current'] / alert['max'],
                              backgroundColor: Colors.deepPurple[50],
                              color: isCritical
                                  ? Colors.deepPurple[400]
                                  : Colors.deepPurple[300],
                              minHeight: 8,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            const SizedBox(height: 12),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Capacity',
                                  style: TextStyle(
                                    color: Colors.deepPurple[500],
                                    fontSize: 13,
                                  ),
                                ),
                                RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text: '${alert['current']}',
                                        style: TextStyle(
                                          color: isCritical
                                              ? Colors.deepPurple[900]
                                              : Colors.deepPurple[700],
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      TextSpan(
                                        text: ' / ${alert['max']}',
                                        style: TextStyle(
                                          color: Colors.deepPurple[500],
                                        ),
                                      ),
                                      TextSpan(
                                        text:
                                            ' (${alert['remaining']} remaining)',
                                        style: TextStyle(
                                          color: Colors.deepPurple[400],
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
