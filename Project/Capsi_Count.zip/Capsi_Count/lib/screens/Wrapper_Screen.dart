import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

import 'SpashScreen.dart';
import 'SignUp.dart';
import 'LogIn.dart';

class Wrapper extends StatefulWidget {
  const Wrapper({super.key});

  @override
  State<Wrapper> createState() => _WrapperState();
}

class _WrapperState extends State<Wrapper> {
  User? user;
  bool isLoading = true;
  bool hasUserData = false;

  @override
  void initState() {
    super.initState();
    _checkUserStatus();
  }

  Future<void> _checkUserStatus() async {
    user = FirebaseAuth.instance.currentUser;

    if (user != null) {
      // User is logged in, fetch user data from Realtime Database
      final databaseRef = FirebaseDatabase.instance.ref("users/${user!.uid}");

      final snapshot = await databaseRef.get();

      if (snapshot.exists) {
        // Print the fetched user data
        print("Fetched user data: ${snapshot.value}");

        // User data exists
        setState(() {
          hasUserData = true;
          isLoading = false;
        });
      } else {
        print("No user data found in database for user ${user!.uid}");
        // No user data found - first time login or incomplete profile
        setState(() {
          hasUserData = false;
          isLoading = false;
        });
      }
    } else {
      print("No logged in user found.");
      // User not logged in
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    } else {
      if (user != null) {
        if (hasUserData) {
          // Logged in and user data exists - show Splash screen
          return SplashScreen();
        } else {
          // Logged in but no user data - show SignUp screen
          return SignUp();
        }
      } else {
        // Not logged in - show Login screen
        return LogIn();
      }
    }
  }
}
