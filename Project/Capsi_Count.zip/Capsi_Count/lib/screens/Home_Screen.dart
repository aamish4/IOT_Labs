import 'dart:async';
import 'package:flutter/material.dart';
import 'package:fresh_check/screens/AddNewEvent_screen.dart';
import 'package:fresh_check/utils/app_colors.dart';
import 'package:fresh_check/widgets/RoomCard_Widget.dart';
import 'package:fresh_check/widgets/pro_Button_Widget.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<String> _imageUrls = [
    "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1591696205602-2f950c417cb9?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1603791440384-56cd371ee9a7?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=800&q=80",
  ];

  int _currentImageIndex = 0;
  Timer? _imageTimer;
  late StreamSubscription<DatabaseEvent> _databaseSubscription;
  final Map<String, dynamic> _roomsData = {};

  @override
  void initState() {
    super.initState();
    _startImageTimer();
    _initializeFirebaseListener();
  }

  void _initializeFirebaseListener() {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) return;

    final dbRef = FirebaseDatabase.instance.ref().child('users').child(userId);

    // First, fetch the initial data
    dbRef.once().then((DatabaseEvent snapshot) {
      if (snapshot.snapshot.value != null) {
        final data = snapshot.snapshot.value as Map<dynamic, dynamic>? ?? {};
        _processData(data);
      }
    });

    // Then set up the continuous listener
    _databaseSubscription = dbRef.onValue.listen((DatabaseEvent event) {
      if (event.snapshot.value != null) {
        final data = event.snapshot.value as Map<dynamic, dynamic>? ?? {};
        _processData(data);
      }
    });
  }

  void _processData(Map<dynamic, dynamic> data) {
    final Map<String, dynamic> newData = {};

    data.forEach((key, value) {
      if (value is Map) {
        newData[key.toString()] = Map<String, dynamic>.from(value);
      }
    });

    setState(() {
      _roomsData.clear();
      _roomsData.addAll(newData);
    });
  }

  void _startImageTimer() {
    _imageTimer = Timer.periodic(const Duration(seconds: 8), (timer) {
      if (mounted) {
        setState(() {
          _currentImageIndex = (_currentImageIndex + 1) % _imageUrls.length;
        });
      }
    });
  }

  @override
  void dispose() {
    _imageTimer?.cancel();
    _databaseSubscription.cancel();
    super.dispose();
  }

  Widget _buildImage(String imageUrl) {
    return Container(
      key: ValueKey<String>(imageUrl),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        image: DecorationImage(
          image: NetworkImage(imageUrl),
          fit: BoxFit.cover,
        ),
      ),
      alignment: Alignment.center,
    );
  }

  Future<void> navigateToAddNewEvent() async {
    final newRoom = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const AddNewEvent()),
    );

    if (newRoom != null && newRoom is Map<String, dynamic>) {
      ScaffoldMessenger.of(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: AppColors.primaryColor,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Padding(
          padding: EdgeInsets.only(left: 20, top: 20),
          child: Text(
            'CapaciCount',
            style: TextStyle(
              fontStyle: FontStyle.italic,
              color: Colors.white,
              fontSize: 30,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        centerTitle: false,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 30, top: 20),
            child: ProButton(
              onTap: () {
                debugPrint('Pro tapped');
              },
            ),
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 35),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: SizedBox(
              height: screenHeight * 0.26,
              width: screenWidth - 40,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 1500),
                  switchInCurve: Curves.easeInOut,
                  switchOutCurve: Curves.easeInOut,
                  transitionBuilder:
                      (Widget child, Animation<double> animation) {
                        final isIncoming =
                            child.key ==
                            ValueKey(_imageUrls[_currentImageIndex]);
                        if (isIncoming) {
                          return SlideTransition(
                            position: Tween<Offset>(
                              begin: const Offset(1.0, 0.0),
                              end: Offset.zero,
                            ).animate(animation),
                            child: child,
                          );
                        } else {
                          return FadeTransition(
                            opacity: animation,
                            child: child,
                          );
                        }
                      },
                  child: _buildImage(_imageUrls[_currentImageIndex]),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: _roomsData.isEmpty
                ? const Center(
                    child: Text('', style: TextStyle(color: Colors.white)),
                  )
                : Scrollbar(
                    thumbVisibility: true,
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      itemCount: _roomsData.length,
                      itemBuilder: (context, index) {
                        final roomKey = _roomsData.keys.elementAt(index);
                        final roomData = _roomsData[roomKey] as Map;

                        // Safely extract values with null checks
                        final currentPersons = roomData['currentPersons'] is int
                            ? roomData['currentPersons'] as int
                            : 0;
                        final maxRange = roomData['maxRange'] is int
                            ? roomData['maxRange'] as int
                            : 0;
                        final temperature = roomData['temperature'] is num
                            ? (roomData['temperature'] as num).toDouble()
                            : 0.0;
                        final humidity = roomData['humidity'] is num
                            ? (roomData['humidity'] as num).toDouble()
                            : 0.0;

                        return RoomCard(
                          title: roomKey,
                          currentPersons: currentPersons,
                          maxRange: maxRange,
                          remainingSpace: (maxRange - currentPersons).clamp(
                            0,
                            maxRange,
                          ),
                          temperature: temperature,
                          humidity: humidity,
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: navigateToAddNewEvent,
        child: const Icon(Icons.add),
      ),
    );
  }
}
