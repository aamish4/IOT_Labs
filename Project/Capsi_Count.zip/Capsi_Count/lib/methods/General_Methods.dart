import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fresh_check/screens/LogIn.dart';

class GeneralMethods {
  // SignUp method
  Future<void> handleSignUp({
    required BuildContext context,
    required TextEditingController nameController,
    required TextEditingController emailController,
    required TextEditingController passwordController,
    required GlobalKey<FormState> formKey,
    required File? selectedImage,
    required String? imagePath,
    required Widget nextScreen,
  }) async {
    if (selectedImage == null) {
      // Removed snackbar notification here
      return;
    }

    if (formKey.currentState!.validate()) {
      FocusScope.of(context).unfocus();

      try {
        UserCredential userCredential = await FirebaseAuth.instance
            .createUserWithEmailAndPassword(
              email: emailController.text.trim(),
              password: passwordController.text.trim(),
            );

        User? user = userCredential.user;

        if (user != null) {
          final databaseRef = FirebaseDatabase.instance.ref(
            "users/${user.uid}",
          );

          await databaseRef.set({
            "uid": user.uid,
            "name": nameController.text.trim(),
            "email": emailController.text.trim(),
            "profileImagePath": imagePath,
          });

          print("User data saved to Realtime Database");

          // Removed success snackbar here

          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => nextScreen),
          );
        }
      } on FirebaseAuthException catch (e) {
        // Removed snackbar for FirebaseAuthException here
      } catch (e) {
        // Removed snackbar for generic exceptions here
      }
    }
  }

  // Login method
  Future<void> handleLogin({
    required BuildContext context,
    required TextEditingController emailController,
    required TextEditingController passwordController,
    required GlobalKey<FormState> formKey,
    required Widget nextScreen,
  }) async {
    if (formKey.currentState!.validate()) {
      FocusScope.of(context).unfocus();

      try {
        UserCredential userCredential = await FirebaseAuth.instance
            .signInWithEmailAndPassword(
              email: emailController.text.trim(),
              password: passwordController.text.trim(),
            );

        User? user = userCredential.user;

        if (user != null) {
          print("Login successful: ${user.email}");

          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => nextScreen),
          );
        }
      } on FirebaseAuthException catch (e) {
        String errorMessage;
        switch (e.code) {
          case 'user-not-found':
            errorMessage = "No user found with this email.";
            break;
          case 'wrong-password':
            errorMessage = "Incorrect password.";
            break;
          default:
            errorMessage = "Login failed: ${e.message}";
        }

        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(errorMessage)));
      } catch (e) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text("Unexpected error: $e")));
      }
    }
  }

  void signOut(BuildContext context) async {
    try {
      await FirebaseAuth.instance.signOut();

      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => LogIn()),
        (Route<dynamic> route) => false,
      );

      print("User signed out successfully");
    } catch (e) {
      print("Sign out failed: $e");
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Sign out failed: $e")));
    }
  }

  void editProfileImageTapped() async {
    print("Edit Tapped");
  }

  // Method for Apply Changes Tapped
  void applyChangesTapped() {
    print("Apply Changes button tapped. Changes will be applied.");
  }

  void darkmode(bool value) {
    print("Dark Mode toggled: $value");
  }

  void MenuItemIndex(int index, BuildContext context) {
    print("Tapped on menu item at index: $index");

    if (index == 7) {
      signOut(context);
    }
  }

  // Method for Delete Account Tapped
  void deleteUserAccountTapped() {
    print("Delete Account button tapped. Proceeding with deletion.");
  }

  String getIconPath(int index) {
    switch (index) {
      case 1:
        return 'assets/icon/sync.png';
      case 2:
        return 'assets/icon/pro.png';
      case 3:
        return 'assets/icon/language.png';
      case 4:
        return 'assets/icon/rate.png';
      case 5:
        return 'assets/icon/support.png';
      case 6:
        return 'assets/icon/privacy.png';
      case 7:
        return 'assets/icon/signout.png';
      default:
        return 'assets/icon/default.png';
    }
  }

  String getMenuItemText(int index) {
    switch (index) {
      case 1:
        return 'Sync';
      case 2:
        return 'Upgrade to Pro';
      case 3:
        return 'Language';
      case 4:
        return 'Rate Us';
      case 5:
        return 'Support';
      case 6:
        return 'Privacy Policy';
      case 7:
        return 'Sign Out';
      default:
        return 'Unknown';
    }
  }
}
